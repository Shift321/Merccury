from django.urls import path, include

from messagesender.views import (
    SendMessageAPIView,
    ShowDialogAPIView,
    ShowMessageAPIView,
    ShowAllDialogsAPIView,
)


urlpatterns = [
    path("send-message", SendMessageAPIView.as_view()),
    path("show-message", ShowMessageAPIView.as_view()),
    path("show-dialog", ShowDialogAPIView.as_view()),
    path("show-all-dialogs", ShowAllDialogsAPIView.as_view()),
]
